/**
 * progress.js
 * ============================================================
 * Logic untuk halaman Progress Peserta (pages/progress.html).
 * Menampilkan satu peserta: identitas, progress bar keseluruhan,
 * dan checklist per program (Tahsin/Tikror/Makhroj) yang menandai
 * setiap pertemuan/modul dengan status: ✅ lulus, ❌ belum lulus,
 * atau "-" belum diambil sama sekali.
 *
 * Mapping kurikulum (LABEL_TIKROR, LABEL_TAHSIN, LABEL_MAKHROJ)
 * di-reuse persis dari quiz.js agar label konsisten di seluruh sistem.
 * ============================================================
 */

document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const namaPeserta = urlParams.get('nama');

    if (!namaPeserta) {
        renderShell('progress', 'Progress Peserta', 'Pilih peserta untuk melihat detail progress');
        document.getElementById('page-body').innerHTML = emptyState(
            'Belum ada peserta dipilih',
            'Buka halaman ini melalui daftar Peserta atau Nilai dengan mengklik salah satu nama.'
        );
        return;
    }

    renderShell('progress', namaPeserta, 'Riwayat dan progress belajar peserta');
    await loadProgressDetail(namaPeserta);
});

async function loadProgressDetail(namaPeserta) {
    const pageBody = document.getElementById('page-body');
    pageBody.innerHTML = `
        <div class="card card-padded" style="margin-bottom:20px;">
            <div class="skeleton" style="width:200px;height:20px;margin-bottom:12px;"></div>
            <div class="skeleton" style="width:100%;height:8px;border-radius:999px;"></div>
        </div>
        <div class="table-wrap"><table><tbody>${skeletonRows(6, 1)}</tbody></table></div>
    `;

    try {
        const res = await getProgressPeserta(namaPeserta);

        if (!res.success) {
            pageBody.innerHTML = emptyState('Peserta tidak ditemukan', res.message || `Belum ada riwayat kuis untuk ${namaPeserta}`);
            showToast(res.message || 'Peserta tidak ditemukan', 'error');
            return;
        }

        renderProgressPage(pageBody, res.data);

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}

function renderProgressPage(container, data) {
    container.innerHTML = `
        <a href="peserta.html" class="btn btn-ghost btn-sm" style="margin-bottom:16px;">← Kembali ke Daftar Peserta</a>

        <div class="card card-padded anim-fade-up" style="margin-bottom:20px;">
            <div style="display:flex; align-items:center; gap:16px; margin-bottom:18px; flex-wrap:wrap;">
                <div class="avatar-initial" style="width:52px;height:52px;font-size:18px;">${getInitials(data.nama)}</div>
                <div style="flex:1; min-width:200px;">
                    <div style="font-size:18px; font-weight:800; color:var(--navy-800);">${escapeHtml(data.nama)}</div>
                    <div style="font-size:13px; color:var(--navy-400); font-weight:600;">Guru: ${escapeHtml(data.guru)}</div>
                </div>
                <div style="display:flex; gap:8px;">
                    <span class="badge badge-tosca">${data.totalKuisDiambil} Kuis Diambil</span>
                    <span class="badge badge-success">${data.totalLulus} Lulus</span>
                </div>
            </div>

            <div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                    <span style="font-size:12.5px; font-weight:700; color:var(--navy-600);">Progress Keseluruhan</span>
                    <span style="font-size:12.5px; font-weight:800; color:var(--tosca-700);">${data.persenProgress}%</span>
                </div>
                <div class="progress-track">
                    <div class="progress-fill" style="width:${data.persenProgress}%"></div>
                </div>
            </div>
        </div>

        <div class="card card-padded anim-fade-up delay-1" style="margin-bottom:20px;">
            <h3 style="font-size:15px; font-weight:800; color:var(--navy-800); margin-bottom:16px;">Riwayat per Program</h3>
            ${renderProgramChecklist('Tahsin', data.byProgram.Tahsin)}
            ${renderProgramChecklist('Tikror', data.byProgram.Tikror)}
            ${renderProgramChecklist('Makhroj', data.byProgram.Makhroj)}
        </div>

        <div class="table-wrap anim-fade-up delay-2">
            <div class="table-toolbar">
                <h3 style="font-size:14.5px; font-weight:800; color:var(--navy-800);">Riwayat Lengkap</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Program</th>
                        <th>Level</th>
                        <th>Modul</th>
                        <th>Pertemuan</th>
                        <th>Nilai</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.riwayatLengkap.map(r => `
                        <tr>
                            <td>${programBadge(r.program)}</td>
                            <td>${escapeHtml(r.level || '—')}</td>
                            <td>${escapeHtml(r.modul || '—')}</td>
                            <td>${escapeHtml(r.pertemuan || '—')}</td>
                            <td class="cell-nilai">${r.nilai}</td>
                            <td>${statusBadge(r.status)}</td>
                            <td>${formatTanggal(r.timestamp)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

/**
 * Render checklist untuk satu program. Mengelompokkan riwayat kuis
 * peserta berdasarkan level+modul (Tahsin), level (Tikror), atau
 * langsung pertemuan (Makhroj), dan menandai status terakhir untuk
 * tiap pertemuan/modul.
 */
function renderProgramChecklist(programName, riwayat) {
    if (!riwayat || riwayat.length === 0) {
        return `
            <div class="checklist-group">
                <div class="checklist-group-title">${programBadge(programName)}</div>
                <div style="font-size:12.5px; color:var(--navy-400); padding:8px 0;">Belum pernah mengikuti kuis ${programName}.</div>
            </div>
        `;
    }

    // Ambil status terbaru per (level+modul+pertemuan) jika ada beberapa
    // kali percobaan untuk kombinasi yang sama
    const latestMap = {};
    riwayat.forEach(r => {
        const key = `${r.level}|${r.modul}|${r.pertemuan}`;
        if (!latestMap[key] || new Date(r.timestamp) > new Date(latestMap[key].timestamp)) {
            latestMap[key] = r;
        }
    });

    const items = Object.values(latestMap).sort((a, b) => {
        // urutkan berdasarkan level lalu modul lalu pertemuan (numerik jika bisa)
        if (a.level !== b.level) return String(a.level).localeCompare(String(b.level));
        if (a.modul !== b.modul) return String(a.modul).localeCompare(String(b.modul));
        return (Number(a.pertemuan) || 0) - (Number(b.pertemuan) || 0);
    });

    const itemsHtml = items.map(r => {
        const labelParts = [];
        if (r.level && r.level !== '-') labelParts.push(r.level);
        if (r.modul && r.modul !== '-') labelParts.push('Modul ' + r.modul);
        if (r.pertemuan && r.pertemuan !== '-') labelParts.push('Pertemuan ' + r.pertemuan);
        const label = labelParts.length > 0 ? labelParts.join(' · ') : programName;

        const isLulus = r.status === 'Lulus';
        const statusIcon = isLulus ? ICONS.checkCircle : ICONS.xCircle;
        const statusClass = isLulus ? 'done' : 'fail';

        return `
            <div class="checklist-item">
                <span>${escapeHtml(label)}</span>
                <div style="display:flex; align-items:center; gap:10px;">
                    <span style="font-size:12px; font-weight:700; color:var(--navy-400);">${r.nilai}</span>
                    <div class="checklist-status ${statusClass}">${statusIcon}</div>
                </div>
            </div>
        `;
    }).join('');

    return `
        <div class="checklist-group">
            <div class="checklist-group-title">${programBadge(programName)} <span style="font-weight:500; color:var(--navy-400); font-size:12px;">${items.length} pertemuan diambil</span></div>
            ${itemsHtml}
        </div>
    `;
}
