/**
 * dashboard.js
 * ============================================================
 * Logic untuk halaman Dashboard (pages/dashboard.html).
 * Menampilkan card statistik agregat dari endpoint ?action=dashboard.
 * ============================================================
 */

document.addEventListener('DOMContentLoaded', async () => {
    renderShell('dashboard', 'Dashboard', 'Ringkasan aktivitas Kuis SobatNgaji');
    await loadDashboardStats();
});

async function loadDashboardStats() {
    const pageBody = document.getElementById('page-body');

    // Skeleton loading state
    pageBody.innerHTML = `
        <div class="stat-grid">
            ${Array(8).fill(0).map(() => `
                <div class="stat-card">
                    <div class="skeleton" style="width:38px;height:38px;border-radius:8px;margin-bottom:14px;"></div>
                    <div class="skeleton skeleton-text" style="width:50%;height:24px;margin-bottom:8px;"></div>
                    <div class="skeleton skeleton-text" style="width:70%;"></div>
                </div>
            `).join('')}
        </div>
    `;

    try {
        const res = await getDashboardStats();

        if (!res.success) {
            pageBody.innerHTML = emptyState('Gagal memuat data', res.message || 'Terjadi kesalahan saat mengambil statistik.');
            showToast(res.message || 'Gagal memuat dashboard', 'error');
            return;
        }

        const d = res.data;
        renderStatCards(pageBody, d);

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda dan coba lagi.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}

function renderStatCards(container, d) {
    const cards = [
        {
            icon: 'users', color: 'tosca',
            value: d.totalPeserta, label: 'Total Peserta'
        },
        {
            icon: 'academic', color: 'navy',
            value: d.pesertaTahsin, label: 'Peserta Tahsin'
        },
        {
            icon: 'academic', color: 'navy',
            value: d.pesertaTikror, label: 'Peserta Tikror'
        },
        {
            icon: 'academic', color: 'gold',
            value: d.pesertaMakhroj, label: 'Peserta Makhroj'
        },
        {
            icon: 'table', color: 'tosca',
            value: d.totalKuis, label: 'Total Kuis Diambil'
        },
        {
            icon: 'checkCircle', color: 'green',
            value: d.totalLulus, label: 'Lulus'
        },
        {
            icon: 'xCircle', color: 'red',
            value: d.totalBelumLulus, label: 'Belum Lulus'
        },
        {
            icon: 'chart', color: 'gold',
            value: d.totalKuis > 0 ? Math.round((d.totalLulus / d.totalKuis) * 100) + '%' : '0%',
            label: 'Tingkat Kelulusan'
        },
    ];

    const cardsHtml = cards.map((c, i) => `
        <div class="stat-card anim-fade-up" style="animation-delay:${i * 0.04}s">
            <div class="stat-card-icon icon-${c.color}">${ICONS[c.icon]}</div>
            <div class="stat-card-value">${c.value}</div>
            <div class="stat-card-label">${c.label}</div>
        </div>
    `).join('');

    container.innerHTML = `
        <div class="stat-grid">${cardsHtml}</div>

        <div class="card card-padded anim-fade-up delay-4">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:4px;">
                <h3 style="font-size:15px; font-weight:800; color:var(--navy-800);">Aksi Cepat</h3>
            </div>
            <p style="font-size:13px; color:var(--navy-400); margin-bottom:16px;">Lompat langsung ke halaman yang sering digunakan</p>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <a href="nilai.html" class="btn btn-primary">${ICONS.table} Lihat Semua Nilai</a>
                <a href="peserta.html" class="btn btn-secondary">${ICONS.users} Daftar Peserta</a>
                <a href="guru.html" class="btn btn-secondary">${ICONS.academic} Daftar Guru</a>
            </div>
        </div>
    `;
}
