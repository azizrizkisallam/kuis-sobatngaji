/**
 * shared.js
 * ============================================================
 * Komponen & helper yang dipakai di SEMUA halaman dashboard:
 * - renderShell()    -> sidebar + topbar (reusable component)
 * - showToast()       -> notifikasi
 * - escapeHtml()       -> sanitasi teks sebelum innerHTML
 * - formatTanggal()    -> format tanggal Indonesia
 * - getInitials()      -> avatar inisial dari nama
 * - skeletonRows()     -> loading state generator
 * ============================================================
 */

const NAV_ITEMS = [
    { key: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: 'grid' },
    { key: 'peserta',   label: 'Peserta',   href: 'peserta.html',   icon: 'users' },
    { key: 'guru',      label: 'Guru',      href: 'guru.html',      icon: 'academic' },
    { key: 'nilai',     label: 'Nilai',     href: 'nilai.html',     icon: 'table' },
    { key: 'progress',  label: 'Progress',  href: 'progress.html',  icon: 'chart' },
];

const ICONS = {
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    academic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c0 1.5 3 3 6 3s6-1.5 6-3v-5"/></svg>',
    table: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
    chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M18 17V9M13 17V5M8 17v-3"/></svg>',
    settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>',
    logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    checkCircle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    xCircle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z"/></svg>',
};

/**
 * Render sidebar + topbar shell ke dalam #app-shell-root.
 * Dipanggil oleh setiap halaman setelah DOM siap.
 * @param {string} activePage - key dari NAV_ITEMS yang sedang aktif
 * @param {string} pageTitle - judul halaman ditampilkan di header
 * @param {string} pageSubtitle - subjudul/deskripsi singkat
 */
function renderShell(activePage, pageTitle, pageSubtitle) {
    const root = document.getElementById('app-shell-root');
    if (!root) return;

    const navHtml = NAV_ITEMS.map(item => `
        <a href="${item.href}" class="nav-item ${item.key === activePage ? 'active' : ''}">
            ${ICONS[item.icon]}
            <span>${item.label}</span>
        </a>
    `).join('');

    const today = new Date();
    const tanggalHariIni = today.toLocaleDateString('id-ID', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });

    root.innerHTML = `
        <div class="sidebar-overlay" id="sidebar-overlay"></div>
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-logo">
                <div class="sidebar-logo-mark">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2 7C2 7 5 5 12 5C19 5 22 7 22 7V19C22 19 19 17 12 17C5 17 2 19 2 19V7Z" stroke="white" stroke-width="2" stroke-linejoin="round"/>
                        <path d="M12 5V17" stroke="white" stroke-width="2"/>
                    </svg>
                </div>
                <div>
                    <div class="sidebar-logo-text">SobatNgaji</div>
                    <div class="sidebar-logo-sub">Admin Panel</div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <div class="sidebar-section-label">Menu Utama</div>
                ${navHtml}

                <div class="sidebar-section-label">Lainnya</div>
                <a href="#" class="nav-item" onclick="showToast('Halaman Pengaturan belum tersedia', 'error'); return false;">
                    ${ICONS.settings}
                    <span>Pengaturan</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                <a href="#" class="nav-item" onclick="showToast('Logout belum tersedia di versi ini', 'error'); return false;">
                    ${ICONS.logout}
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <div class="main-area">
            <header class="topbar">
                <div class="topbar-left">
                    <button class="mobile-menu-btn" id="mobile-menu-btn">${ICONS.menu}</button>
                    <div class="search-box">
                        ${ICONS.search}
                        <input type="text" id="global-search" placeholder="Cari peserta, guru..." autocomplete="off">
                    </div>
                </div>
                <div class="topbar-right">
                    <span class="topbar-date">${tanggalHariIni}</span>
                    <div class="topbar-avatar" title="Admin SobatNgaji">A</div>
                </div>
            </header>

            <main class="page-content">
                <div class="page-header anim-fade-up">
                    <h1 class="page-title">${pageTitle}</h1>
                    <p class="page-subtitle">${pageSubtitle}</p>
                </div>
                <div id="page-body"></div>
            </main>
        </div>
    `;

    // Mobile sidebar toggle
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const menuBtn = document.getElementById('mobile-menu-btn');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('show');
    }
    menuBtn.addEventListener('click', toggleSidebar);
    overlay.addEventListener('click', toggleSidebar);

    // Global search -> redirect ke halaman peserta dengan query
    const searchInput = document.getElementById('global-search');
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && searchInput.value.trim()) {
            window.location.href = `peserta.html?search=${encodeURIComponent(searchInput.value.trim())}`;
        }
    });
}

/**
 * Tampilkan toast notification di pojok kanan bawah.
 * @param {string} message
 * @param {'success'|'error'} type
 */
function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `${type === 'success' ? ICONS.checkCircle : ICONS.xCircle}<span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        setTimeout(() => toast.remove(), 250);
    }, 3000);
}

/** Sanitasi string sebelum dimasukkan ke innerHTML (cegah XSS dari data spreadsheet) */
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str ?? '');
    return div.innerHTML;
}

/** Format ISO timestamp menjadi format tanggal Indonesia singkat */
function formatTanggal(isoString) {
    if (!isoString) return '-';
    try {
        const date = new Date(isoString);
        if (isNaN(date.getTime())) return '-';
        return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch {
        return '-';
    }
}

/** Ambil inisial 1-2 huruf dari nama untuk avatar */
function getInitials(nama) {
    if (!nama) return '?';
    const parts = nama.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

/** Generate badge HTML untuk status Lulus/Belum Lulus */
function statusBadge(status) {
    if (status === 'Lulus') {
        return `<span class="badge badge-success"><span class="badge-dot"></span>Lulus</span>`;
    }
    return `<span class="badge badge-danger"><span class="badge-dot"></span>Belum Lulus</span>`;
}

/** Generate badge HTML untuk program (warna berbeda per program) */
function programBadge(program) {
    const map = {
        Tahsin: 'badge-tosca',
        Tikror: 'badge-navy',
        Makhroj: 'badge-gold'
    };
    const cls = map[program] || 'badge-navy';
    return `<span class="badge ${cls}">${escapeHtml(program)}</span>`;
}

/** Render N baris skeleton loading untuk tabel */
function skeletonRows(count = 6, colCount = 6) {
    let html = '';
    for (let i = 0; i < count; i++) {
        html += '<tr>';
        for (let j = 0; j < colCount; j++) {
            html += `<td><div class="skeleton skeleton-text" style="width:${60 + Math.random() * 40}%"></div></td>`;
        }
        html += '</tr>';
    }
    return html;
}

/** Render empty state generik */
function emptyState(title, desc) {
    return `
        <div class="empty-state">
            <div class="empty-state-icon">${ICONS.inbox}</div>
            <div class="empty-state-title">${escapeHtml(title)}</div>
            <div class="empty-state-desc">${escapeHtml(desc)}</div>
        </div>
    `;
}
