/**
 * guru.js
 * ============================================================
 * Logic untuk halaman Guru (pages/guru.html).
 * Dua mode:
 * 1. List view  -> grid card semua guru dengan ringkasan performa
 * 2. Detail view -> klik salah satu guru, tampil breakdown lengkap
 *    (jumlah peserta, lulus/belum lulus, nilai rata-rata, daftar peserta)
 * Mode ditentukan oleh ?nama=... di URL.
 * ============================================================
 */

document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const namaGuru = urlParams.get('nama');

    if (namaGuru) {
        renderShell('guru', namaGuru, 'Detail performa & daftar peserta');
        await loadGuruDetail(namaGuru);
    } else {
        renderShell('guru', 'Guru', 'Daftar pengajar Kuis SobatNgaji');
        await loadGuruList();
    }
});

async function loadGuruList() {
    const pageBody = document.getElementById('page-body');
    pageBody.innerHTML = `
        <div class="stat-grid" style="grid-template-columns: repeat(3, 1fr);">
            ${Array(6).fill(0).map(() => `
                <div class="card card-padded">
                    <div class="skeleton" style="width:60%;height:18px;margin-bottom:14px;"></div>
                    <div class="skeleton skeleton-text" style="width:80%;margin-bottom:8px;"></div>
                    <div class="skeleton skeleton-text" style="width:50%;"></div>
                </div>
            `).join('')}
        </div>
    `;

    try {
        const res = await getGuruList();

        if (!res.success) {
            pageBody.innerHTML = emptyState('Gagal memuat data', res.message || 'Terjadi kesalahan.');
            showToast(res.message || 'Gagal memuat daftar guru', 'error');
            return;
        }

        const guruList = res.data || [];

        if (guruList.length === 0) {
            pageBody.innerHTML = emptyState('Belum ada data guru', 'Data guru akan muncul setelah ada kuis yang dikerjakan.');
            return;
        }

        guruList.sort((a, b) => b.jumlahPeserta - a.jumlahPeserta);

        pageBody.innerHTML = `
            <div class="stat-grid" style="grid-template-columns: repeat(3, 1fr);">
                ${guruList.map((g, i) => `
                    <div class="card card-padded anim-fade-up" style="animation-delay:${i * 0.04}s; cursor:pointer;"
                         onclick="window.location.href='guru.html?nama=${encodeURIComponent(g.nama)}'">
                        <div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">
                            <div class="avatar-initial" style="width:42px;height:42px;font-size:15px;">${getInitials(g.nama)}</div>
                            <div>
                                <div style="font-weight:800; font-size:14.5px; color:var(--navy-800);">${escapeHtml(g.nama)}</div>
                                <div style="font-size:12px; color:var(--navy-400); font-weight:600;">${g.jumlahPeserta} peserta</div>
                            </div>
                        </div>
                        <div style="display:flex; gap:8px; flex-wrap:wrap;">
                            <span class="badge badge-success">${g.totalLulus} Lulus</span>
                            <span class="badge badge-danger">${g.totalBelumLulus} Belum</span>
                            <span class="badge badge-gold">Avg ${g.nilaiRataRata}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}

async function loadGuruDetail(namaGuru) {
    const pageBody = document.getElementById('page-body');
    pageBody.innerHTML = `
        <div class="stat-grid">
            ${Array(4).fill(0).map(() => `
                <div class="stat-card">
                    <div class="skeleton" style="width:38px;height:38px;border-radius:8px;margin-bottom:14px;"></div>
                    <div class="skeleton skeleton-text" style="width:50%;height:24px;margin-bottom:8px;"></div>
                    <div class="skeleton skeleton-text" style="width:70%;"></div>
                </div>
            `).join('')}
        </div>
        <div class="table-wrap"><table><tbody>${skeletonRows(6, 5)}</tbody></table></div>
    `;

    try {
        const res = await getGuruList(namaGuru);

        if (!res.success) {
            pageBody.innerHTML = emptyState('Guru tidak ditemukan', res.message || `Tidak ada data untuk ${namaGuru}`);
            showToast(res.message || 'Guru tidak ditemukan', 'error');
            return;
        }

        const g = res.data;

        const statCards = [
            { icon: 'users', color: 'tosca', value: g.jumlahPeserta, label: 'Jumlah Peserta' },
            { icon: 'checkCircle', color: 'green', value: g.totalLulus, label: 'Sudah Lulus' },
            { icon: 'xCircle', color: 'red', value: g.totalBelumLulus, label: 'Belum Lulus' },
            { icon: 'chart', color: 'gold', value: g.nilaiRataRata, label: 'Nilai Rata-rata' },
        ];

        pageBody.innerHTML = `
            <a href="guru.html" class="btn btn-ghost btn-sm" style="margin-bottom:16px;">← Kembali ke Daftar Guru</a>

            <div class="stat-grid">
                ${statCards.map((c, i) => `
                    <div class="stat-card anim-fade-up" style="animation-delay:${i * 0.05}s">
                        <div class="stat-card-icon icon-${c.color}">${ICONS[c.icon]}</div>
                        <div class="stat-card-value">${c.value}</div>
                        <div class="stat-card-label">${c.label}</div>
                    </div>
                `).join('')}
            </div>

            <div class="table-wrap anim-fade-up delay-2">
                <div class="table-toolbar">
                    <h3 style="font-size:14.5px; font-weight:800; color:var(--navy-800);">Riwayat Kuis Terbaru</h3>
                </div>
                ${g.riwayat.length === 0 ? emptyState('Belum ada riwayat', 'Guru ini belum memiliki riwayat kuis.') : `
                <table>
                    <thead>
                        <tr>
                            <th>Nama Peserta</th>
                            <th>Program</th>
                            <th>Level</th>
                            <th>Nilai</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${g.riwayat.slice(0, 20).map(r => `
                            <tr onclick="window.location.href='progress.html?nama=${encodeURIComponent(r.nama)}'">
                                <td class="cell-name">
                                    <div style="display:flex; align-items:center; gap:10px;">
                                        <div class="avatar-initial">${getInitials(r.nama)}</div>
                                        ${escapeHtml(r.nama)}
                                    </div>
                                </td>
                                <td>${programBadge(r.program)}</td>
                                <td>${escapeHtml(r.level || '—')}</td>
                                <td class="cell-nilai">${r.nilai}</td>
                                <td>${statusBadge(r.status)}</td>
                                <td>${formatTanggal(r.timestamp)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                `}
            </div>
        `;

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}
