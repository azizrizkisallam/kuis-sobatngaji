/**
 * nilai.js
 * ============================================================
 * Logic untuk halaman Nilai (pages/nilai.html).
 * Tabel modern: search realtime, filter Program/Guru, sort,
 * pagination, export CSV. Data diambil sekali dari ?action=peserta
 * lalu seluruh filter/sort/paginate dilakukan di client-side
 * (cukup cepat untuk skala ratusan-ribuan baris).
 * ============================================================
 */

const PAGE_SIZE = 10;

let state = {
    allData: [],       // data mentah dari API
    filtered: [],       // setelah search + filter
    sortKey: 'timestamp',
    sortDir: 'desc',    // 'asc' | 'desc'
    currentPage: 1,
    searchQuery: '',
    filterProgram: '',
    filterGuru: ''
};

document.addEventListener('DOMContentLoaded', async () => {
    renderShell('nilai', 'Nilai', 'Seluruh hasil kuis peserta SobatNgaji');
    await loadNilaiData();
});

async function loadNilaiData() {
    const pageBody = document.getElementById('page-body');
    pageBody.innerHTML = renderTableSkeleton();

    try {
        const res = await getPesertaList();

        if (!res.success) {
            pageBody.innerHTML = emptyState('Gagal memuat data', res.message || 'Terjadi kesalahan.');
            showToast(res.message || 'Gagal memuat data nilai', 'error');
            return;
        }

        state.allData = res.data || [];
        applyFiltersAndRender();

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}

function renderTableSkeleton() {
    return `
        <div class="table-wrap">
            <div class="table-toolbar">
                <div class="skeleton" style="width:240px;height:36px;"></div>
                <div class="skeleton" style="width:300px;height:36px;"></div>
            </div>
            <table>
                <tbody>${skeletonRows(8, 8)}</tbody>
            </table>
        </div>
    `;
}

function applyFiltersAndRender() {
    let data = [...state.allData];

    // Search realtime: nama, guru, program
    if (state.searchQuery) {
        const q = state.searchQuery.toLowerCase();
        data = data.filter(row =>
            row.nama.toLowerCase().includes(q) ||
            row.guru.toLowerCase().includes(q) ||
            row.program.toLowerCase().includes(q)
        );
    }

    if (state.filterProgram) {
        data = data.filter(row => row.program === state.filterProgram);
    }
    if (state.filterGuru) {
        data = data.filter(row => row.guru === state.filterGuru);
    }

    // Sort
    data.sort((a, b) => {
        let valA = a[state.sortKey];
        let valB = b[state.sortKey];

        if (state.sortKey === 'timestamp') {
            valA = new Date(valA).getTime();
            valB = new Date(valB).getTime();
        } else if (state.sortKey === 'nilai') {
            valA = Number(valA);
            valB = Number(valB);
        } else {
            valA = String(valA).toLowerCase();
            valB = String(valB).toLowerCase();
        }

        if (valA < valB) return state.sortDir === 'asc' ? -1 : 1;
        if (valA > valB) return state.sortDir === 'asc' ? 1 : -1;
        return 0;
    });

    state.filtered = data;
    state.currentPage = 1;
    renderTable();
}

function renderTable() {
    const pageBody = document.getElementById('page-body');

    const programOptions = [...new Set(state.allData.map(r => r.program))].sort();
    const guruOptions = [...new Set(state.allData.map(r => r.guru))].sort();

    const totalRows = state.filtered.length;
    const totalPages = Math.max(1, Math.ceil(totalRows / PAGE_SIZE));
    const startIdx = (state.currentPage - 1) * PAGE_SIZE;
    const pageRows = state.filtered.slice(startIdx, startIdx + PAGE_SIZE);

    const sortArrow = (key) => {
        if (state.sortKey !== key) return '<span class="sort-icon">↕</span>';
        return `<span class="sort-icon">${state.sortDir === 'asc' ? '↑' : '↓'}</span>`;
    };

    pageBody.innerHTML = `
        <div class="table-wrap anim-fade-up">
            <div class="table-toolbar">
                <div class="table-toolbar-filters">
                    <select class="filter-select" id="filter-program">
                        <option value="">Semua Program</option>
                        ${programOptions.map(p => `<option value="${escapeHtml(p)}" ${state.filterProgram === p ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
                    </select>
                    <select class="filter-select" id="filter-guru">
                        <option value="">Semua Guru</option>
                        ${guruOptions.map(g => `<option value="${escapeHtml(g)}" ${state.filterGuru === g ? 'selected' : ''}>${escapeHtml(g)}</option>`).join('')}
                    </select>
                </div>
                <div style="display:flex; gap:8px; align-items:center;">
                    <div class="search-box" style="max-width:240px;">
                        ${ICONS.search}
                        <input type="text" id="table-search" placeholder="Cari nama, guru..." value="${escapeHtml(state.searchQuery)}">
                    </div>
                    <button class="btn btn-secondary btn-sm" id="btn-export-csv">Export CSV</button>
                </div>
            </div>

            ${totalRows === 0 ? emptyState('Tidak ada data', 'Coba ubah kata kunci pencarian atau filter yang digunakan.') : `
            <table>
                <thead>
                    <tr>
                        <th data-sort="nama" class="${state.sortKey === 'nama' ? 'sorted' : ''}">Nama ${sortArrow('nama')}</th>
                        <th data-sort="guru" class="${state.sortKey === 'guru' ? 'sorted' : ''}">Guru ${sortArrow('guru')}</th>
                        <th data-sort="program" class="${state.sortKey === 'program' ? 'sorted' : ''}">Program ${sortArrow('program')}</th>
                        <th>Level</th>
                        <th>Pertemuan</th>
                        <th data-sort="nilai" class="${state.sortKey === 'nilai' ? 'sorted' : ''}">Nilai ${sortArrow('nilai')}</th>
                        <th>Status</th>
                        <th data-sort="timestamp" class="${state.sortKey === 'timestamp' ? 'sorted' : ''}">Tanggal ${sortArrow('timestamp')}</th>
                    </tr>
                </thead>
                <tbody>
                    ${pageRows.map(row => `
                        <tr onclick="window.location.href='progress.html?nama=${encodeURIComponent(row.nama)}'">
                            <td class="cell-name">
                                <div style="display:flex; align-items:center; gap:10px;">
                                    <div class="avatar-initial">${getInitials(row.nama)}</div>
                                    ${escapeHtml(row.nama)}
                                </div>
                            </td>
                            <td>${escapeHtml(row.guru)}</td>
                            <td>${programBadge(row.program)}</td>
                            <td>${escapeHtml(row.level || '—')}</td>
                            <td>${escapeHtml(row.pertemuan || '—')}</td>
                            <td class="cell-nilai">${row.nilai}</td>
                            <td>${statusBadge(row.status)}</td>
                            <td>${formatTanggal(row.timestamp)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="table-pagination">
                <span>Menampilkan ${startIdx + 1}–${Math.min(startIdx + PAGE_SIZE, totalRows)} dari ${totalRows} data</span>
                <div class="pagination-controls">
                    <button class="pagination-btn" id="page-prev" ${state.currentPage === 1 ? 'disabled' : ''}>‹</button>
                    <span style="padding:0 10px;">Hal ${state.currentPage} / ${totalPages}</span>
                    <button class="pagination-btn" id="page-next" ${state.currentPage === totalPages ? 'disabled' : ''}>›</button>
                </div>
            </div>
            `}
        </div>
    `;

    attachTableEvents(totalPages);
}

function attachTableEvents(totalPages) {
    const searchInput = document.getElementById('table-search');
    if (searchInput) {
        searchInput.addEventListener('input', debounce((e) => {
            state.searchQuery = e.target.value;
            applyFiltersAndRender();
            // Restore focus after re-render
            requestAnimationFrame(() => {
                const el = document.getElementById('table-search');
                if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
            });
        }, 250));
    }

    const filterProgram = document.getElementById('filter-program');
    if (filterProgram) filterProgram.addEventListener('change', (e) => {
        state.filterProgram = e.target.value;
        applyFiltersAndRender();
    });

    const filterGuru = document.getElementById('filter-guru');
    if (filterGuru) filterGuru.addEventListener('change', (e) => {
        state.filterGuru = e.target.value;
        applyFiltersAndRender();
    });

    document.querySelectorAll('th[data-sort]').forEach(th => {
        th.addEventListener('click', () => {
            const key = th.dataset.sort;
            if (state.sortKey === key) {
                state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
            } else {
                state.sortKey = key;
                state.sortDir = 'desc';
            }
            applyFiltersAndRender();
        });
    });

    const prevBtn = document.getElementById('page-prev');
    if (prevBtn) prevBtn.addEventListener('click', () => {
        if (state.currentPage > 1) { state.currentPage--; renderTable(); }
    });

    const nextBtn = document.getElementById('page-next');
    if (nextBtn) nextBtn.addEventListener('click', () => {
        if (state.currentPage < totalPages) { state.currentPage++; renderTable(); }
    });

    const exportBtn = document.getElementById('btn-export-csv');
    if (exportBtn) exportBtn.addEventListener('click', exportToCsv);
}

function exportToCsv() {
    if (state.filtered.length === 0) {
        showToast('Tidak ada data untuk diexport', 'error');
        return;
    }

    const headers = ['Nama', 'Guru', 'Program', 'Level', 'Modul', 'Pertemuan', 'Nilai', 'Status', 'Tanggal'];
    const rows = state.filtered.map(r => [
        r.nama, r.guru, r.program, r.level, r.modul, r.pertemuan, r.nilai, r.status, formatTanggal(r.timestamp)
    ]);

    let csv = headers.join(',') + '\n';
    rows.forEach(row => {
        csv += row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nilai-sobatngaji-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    showToast('Data berhasil diexport ke CSV', 'success');
}

/** Debounce helper untuk search realtime agar tidak re-render tiap keystroke */
function debounce(fn, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}
