/**
 * api.js
 * ============================================================
 * Modul terpusat untuk semua komunikasi dengan Google Apps Script
 * backend. Endpoint LAMA (getQuestions, certificate) TIDAK diubah
 * sama sekali — hanya dipindah ke sini agar quiz.js bisa reuse.
 *
 * Endpoint BARU (dashboard, peserta, guru, progress) ditambahkan
 * untuk kebutuhan admin dashboard.
 * ============================================================
 */

const API_URL = 'https://script.google.com/macros/s/AKfycbzeADK2epnaT64sqH9qqSHEdlePc0kfWiJuGsJS4f8VzSxj5mXIL0ZxC7LE9sLx7y2D/exec';

/**
 * Helper inti: fetch GET ke Apps Script dengan query params.
 * @param {string} action - nilai parameter ?action=
 * @param {object} params - parameter tambahan (key-value)
 * @returns {Promise<object>} response JSON dari Apps Script
 */
async function apiGet(action, params = {}) {
    const query = new URLSearchParams({ action, ...params });
    const response = await fetch(`${API_URL}?${query.toString()}`);
    if (!response.ok) {
        throw new Error(`Request gagal (HTTP ${response.status})`);
    }
    return response.json();
}

/**
 * Helper inti: POST JSON ke Apps Script (dipakai untuk simpan hasil kuis).
 * @param {object} payload
 * @returns {Promise<object>}
 */
async function apiPost(payload) {
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payload)
    });
    return response.json();
}

// ============================================================
// ENDPOINT LAMA (struktur & nama TIDAK diubah, demi backward compat)
// ============================================================

/**
 * Ambil soal kuis. Sama persis dengan logic lama di file HTML monolitik.
 * @param {object} params - { program, jenis, level, modul, pertemuan }
 */
async function getQuestions(params) {
    return apiGet('getQuestions', params);
}

/**
 * Kirim hasil kuis peserta untuk disimpan ke spreadsheet.
 * @param {object} payload - { nama, guru, program, level, modul, pertemuan, nilai, status }
 */
async function submitQuizResult(payload) {
    return apiPost(payload);
}

/**
 * Generate & ambil URL sertifikat kenaikan level.
 * @param {object} params - { nama, program, level }
 */
async function getCertificate(params) {
    return apiGet('certificate', params);
}

// ============================================================
// ENDPOINT BARU (untuk Dashboard Admin)
// ============================================================

/**
 * Ambil statistik agregat untuk card-card di halaman Dashboard.
 * Returns: { totalPeserta, pesertaTahsin, pesertaTikror, pesertaMakhroj,
 *            totalKuis, totalLulus, totalBelumLulus }
 */
async function getDashboardStats() {
    return apiGet('dashboard');
}

/**
 * Ambil daftar seluruh hasil kuis (untuk tabel Nilai/Peserta).
 * @param {object} filters - { program, guru, nama } (semua opsional)
 */
async function getPesertaList(filters = {}) {
    return apiGet('peserta', filters);
}

/**
 * Ambil daftar ringkasan semua guru, atau detail satu guru jika
 * parameter nama diberikan.
 * @param {string} [namaGuru] - opsional, jika ingin detail satu guru
 */
async function getGuruList(namaGuru = '') {
    const params = namaGuru ? { nama: namaGuru } : {};
    return apiGet('guru', params);
}

/**
 * Ambil riwayat progress lengkap satu peserta berdasarkan nama.
 * @param {string} namaPeserta
 */
async function getProgressPeserta(namaPeserta) {
    return apiGet('progress', { nama: namaPeserta });
}
