/**
 * quiz.js
 * ============================================================
 * Logic kuis SobatNgaji (Tahsin, Tikror, Makhroj). Logic DIPINDAH
 * persis sama dari file HTML monolitik lama — TIDAK ADA PERUBAHAN
 * pada alur, validasi, atau payload. Satu-satunya perubahan adalah
 * struktural: API_URL kini didefinisikan terpusat di api.js (di-load
 * sebelum file ini), bukan diduplikasi di sini.
 * ============================================================
 */

// ════════════════════════════════════════
    // AUDIO
    // ════════════════════════════════════════
    const audio = document.getElementById('bg-audio');
    const audioBtn = document.getElementById('audio-toggle');
    let audioUnlocked = false;
    let audioOn = false;
    audio.volume = 0.08;

    function unlockAudio() {
        if (!audioUnlocked) {
            audioUnlocked = true;
            document.removeEventListener('click', unlockAudio);
        }
    }
    document.addEventListener('click', unlockAudio, { once: true });

    audioBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!audioUnlocked) { unlockAudio(); }
        if (audioOn) {
            audio.pause();
            audioBtn.textContent = '🔇';
            audioOn = false;
        } else {
            audio.play().catch(() => {});
            audioBtn.textContent = '🔊';
            audioOn = true;
        }
    });

    // ════════════════════════════════════════
    // API + STATE
    // ════════════════════════════════════════

    const formSetup   = document.getElementById('setup-form');
    const formQuiz    = document.getElementById('quiz-form');
    const jenisSelect = document.getElementById('jenis');
    const programSelect = document.getElementById('program');
    const levelSelect = document.getElementById('level');
    const modulSelect = document.getElementById('modul');
    const pertemuanSelect = document.getElementById('pertemuan');

    const divLevel    = document.getElementById('div-level');
    const divModul    = document.getElementById('div-modul');
    const divPertemuan = document.getElementById('div-pertemuan');
    const dynamicFields = document.getElementById('dynamic-fields');

    let questionsData = [];
    let answersData   = {};
    let certPayloadData = {};

    // ════════════════════════════════════════
    // CURRICULUM MAPPING
    // ════════════════════════════════════════
    const LABEL_TIKROR = {
        1:  'Huruf Hamzah (ء) dan Ba (ب)',
        2:  'Huruf Ta (ت)',
        3:  'Huruf Tsa (ث) dan Jim (ج)',
        4:  'Huruf Ha (ح) dan Kha (خ)',
        5:  'Huruf Dal (د) dan Dzal (ذ)',
        6:  'Huruf Ra (ر) dan Zai (ز)',
        7:  'Huruf Sin (س) dan Syin (ش)',
        8:  'Huruf Shad (ص) dan Dhad (ض)',
        9:  'Huruf Tha (ط) dan Zha (ظ)',
        10: 'Huruf Ain (ع) dan Ghain (غ)',
        11: 'Huruf Fa (ف) dan Qaf (ق)',
        12: 'Huruf Kaf (ك) dan Lam (ل)',
        13: 'Huruf Mim (م) dan Nun (ن)',
        14: 'Huruf Wau (و), Ha (هـ), Ya (ي)',
        15: 'Harakat',
        16: 'Huruf Sambung',
        17: 'Mad 2 Harakat (Fathah + Alif)',
        18: 'Mad 2 Harakat (Fathah Berdiri)',
        19: 'Mad 2 Harakat (Kasrah + Ya Sukun)',
        20: 'Mad 2 Harakat (Dhammah + Wau Sukun)',
        21: 'Talaqqi Al Fatihah',
        22: 'Tanwin',
        23: 'Ta Marbuthah',
        24: 'Huruf Sukun',
        25: "Huruf Sukun dengan Sifat Isti'la",
        26: 'Huruf Sukun dengan Sifat Syiddah',
        27: 'Latihan Huruf Sukun Syiddah & Qalqalah',
        28: 'Huruf Sukun dengan Sifat Rakhawah',
        29: 'Huruf Sukun pada Huruf Alif Lam',
        30: 'Tasydid pada Huruf Nun dan Mim',
        31: 'Tasydid pada Huruf Alif Lam',
        32: 'Latihan Huruf Lam Bertasydid'
    };

    const LABEL_MAKHROJ = {
        1:  'Muqoddimah Makhroj',
        2:  'Sifatul Huruf',
        3:  'Al Jauf',
        4:  'Al Khaisyum',
        5:  'Huruf Hamzah',
        6:  'Huruf Ha Kecil',
        7:  'Huruf Ain',
        8:  'Huruf Ha Besar',
        9:  'Huruf Ghain',
        10: 'Huruf Kha',
        11: "Latihan QS Al-A'la",
        12: 'Makhroj Lisan',
        13: 'Huruf Qaf',
        14: 'Huruf Kaf',
        15: 'Huruf Jim',
        16: 'Huruf Syin',
        17: 'Huruf Ya',
        18: 'Huruf Dhad',
        19: 'Huruf Lam',
        20: 'Huruf Nun',
        21: 'Huruf Ra',
        22: 'Huruf Tha',
        23: 'Huruf Dal',
        24: 'Huruf Ta',
        25: 'Huruf Shad',
        26: 'Huruf Zay',
        27: 'Huruf Sin',
        28: 'Huruf Zha',
        29: 'Huruf Dzal',
        30: 'Huruf Tsa',
        31: 'Latihan QS Al-Buruj',
        32: 'Huruf Wau',
        33: 'Huruf Ba',
        34: 'Huruf Fa',
        35: 'Huruf Mim',
        36: 'Pola Metode Banaba Semua Huruf'
    };

    const LABEL_TAHSIN = {
        'Tahsin 1': {
            'A': {
                1: 'Rumus 1 Detik Hafal 7 Tanda Mad 2 Harakat',
                2: 'Pola Asyik Mad 2 Harakat',
                3: '28 Pola Mad 2 Harakat',
                4: 'Latihan Level 1 Mad 2 Harakat',
                5: 'Latihan Level 2 Mad 2 Harakat',
                6: 'Mad Iwadh & Mad Shilah',
                7: 'Mad Aridh & Mad Lin',
                8: 'Talaqqi QS Taha Ayat 55–57'
            },
            'B': {
                1: 'Mad Wajib Muttashil & Mad Jaiz Munfashil',
                2: 'Mad Jaiz menurut Thariqah Syathibi & Jazari',
                3: 'Makna Mad Wajib & Mad Jaiz',
                4: 'Mad Jaiz Munfashil Haqiqi'
            },
            'C': {
                1: 'Mad Lazim Mutsaqqal Kalimi',
                2: 'Latihan Mad 6 Harakat Level 1',
                3: 'Latihan Mad 6 Harakat Level 2',
                4: 'Makna Mad Lazim'
            },
            'D': {
                1: 'Alif Lam Syamsiyyah',
                2: 'Alif Lam Qamariyyah',
                3: 'Huruf Fawatihus Suwar',
                4: 'Talaqqi QS Asy-Syura Ayat 1–6'
            }
        },
        'Tahsin 2': {
            'A': {
                1: 'Ghunnah Musyaddadah & Idgham Mimi',
                2: 'Latihan Ghunnah',
                3: 'Idgham Bighunnah',
                4: 'Talaqqi QS Az-Zalzalah'
            },
            'B': {
                1: 'Ikhfa Syafawi',
                2: 'Iqlab',
                3: 'Ikhfa Haqiqi',
                4: 'Talaqqi QS At-Tahrim'
            },
            'C': {
                1: 'Idzhar Halqi',
                2: 'Idzhar Syafawi'
            },
            'D': {
                1: 'Qalqalah Sughra & Kubra',
                2: 'Talaqqi QS Al-Lahab'
            }
        }
    };

    // ════════════════════════════════════════
    // FORM UI LOGIC
    // ════════════════════════════════════════
    jenisSelect.addEventListener('change', updateFormUI);
    programSelect.addEventListener('change', updateFormUI);
    levelSelect.addEventListener('change', updatePertemuanOptions);
    modulSelect.addEventListener('change', updatePertemuanOptions);

    function showDynamic() {
        dynamicFields.style.display = '';
        dynamicFields.style.animation = 'fadeUp 0.3s ease both';
    }
    function hideDynamic() { dynamicFields.style.display = 'none'; }

    function updateFormUI() {
        const prog  = programSelect.value;
        const jenis = jenisSelect.value;

        divLevel.classList.add('hidden');
        divModul.classList.add('hidden');
        divPertemuan.classList.add('hidden');
        levelSelect.innerHTML = '';

        if (!prog || !jenis) { hideDynamic(); return; }

        showDynamic();

        if (prog === 'Tahsin') {
            divLevel.classList.remove('hidden');
            if (jenis === 'Pertemuan') {
                divModul.classList.remove('hidden');
                divPertemuan.classList.remove('hidden');
            }
            levelSelect.innerHTML = '<option value="Tahsin 1">Tahsin 1</option><option value="Tahsin 2">Tahsin 2</option>';
            updatePertemuanOptions();
        } else if (prog === 'Tikror') {
            divLevel.classList.remove('hidden');
            if (jenis === 'Pertemuan') divPertemuan.classList.remove('hidden');
            levelSelect.innerHTML = '<option value="Tikror 1">Tikror 1</option><option value="Tikror 2">Tikror 2</option><option value="Tikror 3">Tikror 3</option>';
            updatePertemuanOptions();
        } else if (prog === 'Makhroj') {
            divPertemuan.classList.remove('hidden');
            isiPertemuanMakhroj();
        }
    }

    function isiPertemuan(start, end) {
        pertemuanSelect.innerHTML = '';
        for (let i = start; i <= end; i++) {
            const lbl = LABEL_TIKROR[i] ? `Pertemuan ${i} — ${LABEL_TIKROR[i]}` : `Pertemuan ${i}`;
            pertemuanSelect.innerHTML += `<option value="${i}">${lbl}</option>`;
        }
    }

    function isiPertemuanMakhroj() {
        pertemuanSelect.innerHTML = '';
        for (let i = 1; i <= 36; i++) {
            const lbl = LABEL_MAKHROJ[i] ? `Pertemuan ${i} — ${LABEL_MAKHROJ[i]}` : `Pertemuan ${i}`;
            pertemuanSelect.innerHTML += `<option value="${i}">${lbl}</option>`;
        }
    }

    function updatePertemuanOptions() {
        const prog  = programSelect.value;
        pertemuanSelect.innerHTML = '';

        if (prog === 'Tahsin') {
            const level = levelSelect.value;
            const modul = modulSelect.value;
            let max = 4;
            if (level === 'Tahsin 1' && modul === 'A') max = 8;
            else if (level === 'Tahsin 2' && (modul === 'C' || modul === 'D')) max = 2;
            else max = 4;

            for (let i = 1; i <= max; i++) {
                const lbl = LABEL_TAHSIN[level] && LABEL_TAHSIN[level][modul] && LABEL_TAHSIN[level][modul][i];
                const text = lbl ? `Pertemuan ${i} — ${lbl}` : `Pertemuan ${i}`;
                pertemuanSelect.innerHTML += `<option value="${i}">${text}</option>`;
            }
        } else if (prog === 'Tikror') {
            if (levelSelect.value === 'Tikror 1') { isiPertemuan(1, 14); return; }
            if (levelSelect.value === 'Tikror 2') { isiPertemuan(15, 21); return; }
            if (levelSelect.value === 'Tikror 3') { isiPertemuan(22, 32); return; }
        }
    }

    // ════════════════════════════════════════
    // FORM SUBMIT → FETCH QUESTIONS
    // ════════════════════════════════════════
    formSetup.addEventListener('submit', async (e) => {
        e.preventDefault();
        const jenis = jenisSelect.value;
        const prog  = programSelect.value;

        let params = new URLSearchParams({ action: 'getQuestions', program: prog, jenis: jenis });

        if (prog === 'Tahsin') {
            params.append('level', levelSelect.value);
            if (jenis === 'Pertemuan') {
                params.append('modul', modulSelect.value);
                params.append('pertemuan', pertemuanSelect.value);
            }
        } else if (prog === 'Tikror') {
            params.append('level', levelSelect.value);
            if (jenis === 'Pertemuan') params.append('pertemuan', pertemuanSelect.value);
        } else if (prog === 'Makhroj') {
            params.append('pertemuan', pertemuanSelect.value);
        }

        Swal.fire({
            title: 'Menyiapkan Soal...',
            html: '<span style="font-family:Plus Jakarta Sans,sans-serif;color:#0F766E">Mohon tunggu sebentar ya 🕌</span>',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        try {
            const response = await fetch(`${API_URL}?${params.toString()}`);
            const data = await response.json();
            if (data.success === false) throw new Error(data.message);
            if (!data || data.length === 0) throw new Error('Bank soal kosong atau soal belum tersedia.');

            questionsData = data;
            answersData   = {};
            renderQuestions();

            document.getElementById('setup-section').classList.add('hidden');
            document.getElementById('quiz-section').classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
            Swal.close();
        } catch (error) {
            Swal.fire({ icon: 'error', title: 'Mohon Maaf', text: error.message, confirmButtonColor: '#0F766E' });
        }
    });

    // ════════════════════════════════════════
    // RENDER QUESTIONS
    // ════════════════════════════════════════
    function renderQuestions() {
        const container = document.getElementById('questions-container');
        container.innerHTML = '';

        questionsData.forEach((q, index) => {
            const no = index + 1;
            const delay = Math.min(index * 0.06, 0.4);
            const html = `
                <div class="glass-strong rounded-2xl p-6 anim-fade-up" style="animation-delay:${delay}s">
                    <div class="flex items-start gap-3 mb-5">
                        <div class="q-number">${no}</div>
                        <h3 class="text-base font-700 text-brand-900 leading-relaxed pt-0.5 flex-1">${q.soal}</h3>
                    </div>
                    <div class="space-y-3" id="opts-${index}">
                        ${['A','B','C','D'].map(opt => `
                            <label class="option-label" id="lbl-${index}-${opt}">
                                <input type="radio" name="q${index}" value="${opt}"
                                    class="sr-only"
                                    onchange="selectOption(${index}, '${opt}')">
                                <div class="option-dot-outer">
                                    <div class="option-dot-inner"></div>
                                </div>
                                <div class="option-key">${opt}</div>
                                <span class="option-text">${q[opt]}</span>
                            </label>
                        `).join('')}
                    </div>
                </div>
            `;
            container.innerHTML += html;
        });
        updateProgressUI();
    }

    window.selectOption = function(index, value) {
        // Clear all options for this question
        ['A','B','C','D'].forEach(opt => {
            const lbl = document.getElementById(`lbl-${index}-${opt}`);
            if (lbl) lbl.classList.remove('selected');
        });
        // Mark selected
        const selected = document.getElementById(`lbl-${index}-${value}`);
        if (selected) selected.classList.add('selected');

        answersData[index] = value;
        updateProgressUI();
    };

    // Keep backward compat
    window.updateProgress = window.selectOption;

    function updateProgressUI() {
        const total    = questionsData.length;
        const answered = Object.keys(answersData).length;
        const pct      = total ? (answered / total) * 100 : 0;

        document.getElementById('progress-bar-fill').style.width = `${pct}%`;
        document.getElementById('progress-text').innerText = `${answered}/${total}`;
        document.getElementById('progress-count-pill').innerText = `${answered} dijawab`;
    }

    // ════════════════════════════════════════
    // QUIZ SUBMIT
    // ════════════════════════════════════════
    formQuiz.addEventListener('submit', async (e) => {
        e.preventDefault();
        const totalSoal = questionsData.length;
        const dijawab   = Object.keys(answersData).length;

        if (dijawab < totalSoal) {
            Swal.fire({ icon: 'warning', title: 'Masih Ada Soal', text: 'Harap jawab semua soal terlebih dahulu.', confirmButtonColor: '#0F766E' });
            return;
        }

        let benar = 0;
        questionsData.forEach((q, i) => { if (answersData[i] === q.kunci) benar++; });

        const nilai      = Math.round((benar / totalSoal) * 100);
        const statusText = nilai >= 80 ? 'Lulus' : 'Belum Lulus';
        const jenis      = jenisSelect.value;
        const prog       = programSelect.value;

        const payload = {
            nama:      document.getElementById('nama').value,
            guru:      document.getElementById('guru').value,
            program:   prog,
            level:     (prog === 'Makhroj') ? '-' : levelSelect.value,
            modul:     (prog === 'Tahsin' && jenis === 'Pertemuan') ? modulSelect.value : '-',
            pertemuan: (jenis === 'Pertemuan') ? pertemuanSelect.value : '-',
            nilai:     nilai,
            status:    statusText
        };

        Swal.fire({
            title: 'Mengirim Jawaban...',
            html: '<span style="font-family:Plus Jakarta Sans,sans-serif;color:#0F766E">Semoga hasilnya maksimal! 🤲</span>',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        try {
            await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify(payload)
            });
            tampilkanHasil(payload, jenis, benar, totalSoal);
        } catch (error) {
            tampilkanHasil(payload, jenis, benar, totalSoal);
        }
    });

    // ════════════════════════════════════════
    // CONFETTI
    // ════════════════════════════════════════
    function launchConfetti() {
        const colors = ['#14B8A6','#0F766E','#99f6e9','#fbbf24','#34d399','#5eead6'];
        for (let i = 0; i < 80; i++) {
            const el = document.createElement('div');
            el.className = 'confetti-piece';
            el.style.left = Math.random() * 100 + 'vw';
            el.style.top  = '-12px';
            el.style.background = colors[Math.floor(Math.random() * colors.length)];
            el.style.width  = (6 + Math.random() * 8) + 'px';
            el.style.height = (6 + Math.random() * 8) + 'px';
            el.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
            el.style.animationDuration = (2 + Math.random() * 2) + 's';
            el.style.animationDelay    = (Math.random() * 0.8) + 's';
            document.body.appendChild(el);
            el.addEventListener('animationend', () => el.remove());
        }
    }

    // ════════════════════════════════════════
    // TAMPILKAN HASIL
    // ════════════════════════════════════════
    function tampilkanHasil(data, jenisKuis, benar, totalSoal) {
        Swal.close();
        document.getElementById('quiz-section').classList.add('hidden');
        document.getElementById('result-section').classList.remove('hidden');

        // Score ring
        const pct = data.nilai;
        document.getElementById('score-ring').style.setProperty('--pct', pct + '%');
        document.getElementById('result-score').innerText = data.nilai;
        document.getElementById('result-correct-count').innerText = `Jawaban benar: ${benar} dari ${totalSoal} soal`;

        // Status
        const statusEl = document.getElementById('result-status');
        if (data.status === 'Lulus') {
            document.getElementById('result-emoji').innerText   = '🏆';
            document.getElementById('result-heading').innerText = 'Alhamdulillah, Lulus!';
            document.getElementById('result-subtext').innerText = 'Terus semangat belajar Al-Qur\'an';
            statusEl.innerHTML = '<div class="status-lulus">✅ LULUS</div>';
            setTimeout(launchConfetti, 300);

            if (jenisKuis === 'Kenaikan') {
                document.getElementById('cert-container').classList.remove('hidden');
                certPayloadData = {
                    nama:    data.nama,
                    program: data.program,
                    level:   data.level
                };
            }
        } else {
            document.getElementById('result-emoji').innerText   = '📚';
            document.getElementById('result-heading').innerText = 'Belum Lulus';
            document.getElementById('result-subtext').innerText = 'Jangan menyerah, terus berlatih!';
            statusEl.innerHTML = '<div class="status-belum">📚 BELUM LULUS</div>';
        }

        // Info rows
        document.getElementById('res-guru').innerText    = data.guru;
        document.getElementById('res-program').innerText = data.program;

        if (data.program === 'Makhroj') {
            document.getElementById('wrap-res-level').classList.add('hidden');
            document.getElementById('label-res-modul').innerText = 'Modul';
            document.getElementById('res-modul').innerText = '—';
            if (data.pertemuan === '-') {
                document.getElementById('wrap-res-pertemuan').classList.add('hidden');
            } else {
                document.getElementById('wrap-res-pertemuan').classList.remove('hidden');
                document.getElementById('res-pertemuan').innerText = data.pertemuan;
            }
        } else if (data.program === 'Tikror') {
            document.getElementById('wrap-res-level').classList.remove('hidden');
            document.getElementById('res-level').innerText  = data.level;
            document.getElementById('label-res-modul').innerText = 'Modul';
            document.getElementById('res-modul').innerText  = '—';
            if (data.pertemuan === '-') {
                document.getElementById('wrap-res-pertemuan').classList.add('hidden');
            } else {
                document.getElementById('wrap-res-pertemuan').classList.remove('hidden');
                document.getElementById('res-pertemuan').innerText = data.pertemuan;
            }
        } else {
            document.getElementById('wrap-res-level').classList.remove('hidden');
            document.getElementById('res-level').innerText  = data.level;
            document.getElementById('label-res-modul').innerText = 'Modul';
            document.getElementById('res-modul').innerText  = data.modul;
            if (data.pertemuan === '-') {
                document.getElementById('wrap-res-pertemuan').classList.add('hidden');
            } else {
                document.getElementById('wrap-res-pertemuan').classList.remove('hidden');
                document.getElementById('res-pertemuan').innerText = data.pertemuan;
            }
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // ════════════════════════════════════════
    // SERTIFIKAT
    // ════════════════════════════════════════
    async function unduhSertifikat() {
        if (!certPayloadData || !certPayloadData.program) {
            Swal.fire({ icon: 'error', title: 'Gagal', text: 'Data peserta tidak lengkap.', confirmButtonColor: '#0F766E' });
            return;
        }
        Swal.fire({
            title: 'Membuat Sertifikat...',
            html: '<span style="font-family:Plus Jakarta Sans,sans-serif;color:#0F766E">Mohon tunggu sebentar ya 🎓</span>',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });
        try {
            const getParams = new URLSearchParams({
                action:  'certificate',
                nama:    certPayloadData.nama,
                program: certPayloadData.program,
                level:   certPayloadData.level
            });
            const response = await fetch(`${API_URL}?${getParams.toString()}`);
            const res = await response.json();
            if (res.status === 'success' || res.success === true) {
                Swal.fire({
                    icon: 'success',
                    title: 'Alhamdulillah Berhasil!',
                    text: 'Sertifikat Anda telah siap.',
                    confirmButtonText: 'Buka Sertifikat 🏆',
                    confirmButtonColor: '#0F766E'
                }).then((result) => {
                    if (result.isConfirmed && res.url) window.open(res.url, '_blank');
                });
            } else {
                throw new Error(res.message || 'Terjadi kesalahan sistem di server.');
            }
        } catch (error) {
            Swal.fire({ icon: 'error', title: 'Mohon Maaf', text: 'Gagal membuat sertifikat: ' + error.message, confirmButtonColor: '#0F766E' });
        }
    }

    // Expose globally
    window.unduhSertifikat = unduhSertifikat;