/**
 * peserta.js
 * ============================================================
 * Logic untuk halaman Peserta (pages/peserta.html).
 * Berbeda dengan Nilai (yang menampilkan per-baris-kuis), halaman
 * ini mengelompokkan data per PESERTA UNIK: nama, guru, program
 * yang diikuti, nilai terakhir, status terakhir, dan ringkasan
 * progress (jumlah lulus / total kuis diambil).
 * ============================================================
 */

let pesertaState = {
    allRows: [],     // data mentah per baris kuis dari API
    grouped: [],     // data sudah dikelompokkan per nama
    filtered: [],
    searchQuery: ''
};

document.addEventListener('DOMContentLoaded', async () => {
    renderShell('peserta', 'Peserta', 'Daftar seluruh peserta Kuis SobatNgaji');

    // Cek apakah ada query search dari global search bar (?search=...)
    const urlParams = new URLSearchParams(window.location.search);
    const searchFromUrl = urlParams.get('search');
    if (searchFromUrl) pesertaState.searchQuery = searchFromUrl;

    await loadPesertaData();
});

async function loadPesertaData() {
    const pageBody = document.getElementById('page-body');
    pageBody.innerHTML = `
        <div class="table-wrap">
            <div class="table-toolbar">
                <div class="skeleton" style="width:280px;height:36px;"></div>
            </div>
            <table><tbody>${skeletonRows(8, 6)}</tbody></table>
        </div>
    `;

    try {
        const res = await getPesertaList();

        if (!res.success) {
            pageBody.innerHTML = emptyState('Gagal memuat data', res.message || 'Terjadi kesalahan.');
            showToast(res.message || 'Gagal memuat data peserta', 'error');
            return;
        }

        pesertaState.allRows = res.data || [];
        pesertaState.grouped = groupByPeserta(pesertaState.allRows);
        applyPesertaFilter();

    } catch (error) {
        pageBody.innerHTML = emptyState('Gagal memuat data', 'Periksa koneksi internet Anda.');
        showToast('Gagal terhubung ke server: ' + error.message, 'error');
    }
}

/** Kelompokkan baris-baris hasil kuis menjadi satu objek per peserta unik */
function groupByPeserta(rows) {
    const map = {};

    rows.forEach(row => {
        if (!map[row.nama]) {
            map[row.nama] = {
                nama: row.nama,
                guru: row.guru,
                programSet: new Set(),
                totalKuis: 0,
                totalLulus: 0,
                nilaiTerakhir: row.nilai,
                statusTerakhir: row.status,
                timestampTerakhir: row.timestamp
            };
        }
        const p = map[row.nama];
        p.programSet.add(row.program);
        p.totalKuis++;
        if (row.status === 'Lulus') p.totalLulus++;

        // Update "terakhir" jika baris ini lebih baru
        if (new Date(row.timestamp) > new Date(p.timestampTerakhir)) {
            p.nilaiTerakhir = row.nilai;
            p.statusTerakhir = row.status;
            p.timestampTerakhir = row.timestamp;
            p.guru = row.guru; // guru pengampu terbaru
        }
    });

    return Object.values(map).map(p => ({
        ...p,
        programList: Array.from(p.programSet),
        persenProgress: p.totalKuis > 0 ? Math.round((p.totalLulus / p.totalKuis) * 100) : 0
    })).sort((a, b) => new Date(b.timestampTerakhir) - new Date(a.timestampTerakhir));
}

function applyPesertaFilter() {
    let data = [...pesertaState.grouped];

    if (pesertaState.searchQuery) {
        const q = pesertaState.searchQuery.toLowerCase();
        data = data.filter(p =>
            p.nama.toLowerCase().includes(q) ||
            p.guru.toLowerCase().includes(q) ||
            p.programList.some(prog => prog.toLowerCase().includes(q))
        );
    }

    pesertaState.filtered = data;
    renderPesertaGrid();
}

function renderPesertaGrid() {
    const pageBody = document.getElementById('page-body');
    const data = pesertaState.filtered;

    pageBody.innerHTML = `
        <div class="card-padded card anim-fade-up" style="margin-bottom:18px;">
            <div class="search-box" style="max-width:360px;">
                ${ICONS.search}
                <input type="text" id="peserta-search" placeholder="Cari nama peserta, guru, atau program..." value="${escapeHtml(pesertaState.searchQuery)}">
            </div>
        </div>

        ${data.length === 0 ? emptyState('Belum ada peserta', 'Data peserta akan muncul setelah ada yang mengerjakan kuis.') : `
        <div class="table-wrap anim-fade-up delay-1">
            <table>
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Guru</th>
                        <th>Program Diikuti</th>
                        <th>Nilai Terakhir</th>
                        <th>Status</th>
                        <th>Progress</th>
                        <th>Terakhir Aktif</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.map(p => `
                        <tr onclick="window.location.href='progress.html?nama=${encodeURIComponent(p.nama)}'">
                            <td class="cell-name">
                                <div style="display:flex; align-items:center; gap:10px;">
                                    <div class="avatar-initial">${getInitials(p.nama)}</div>
                                    ${escapeHtml(p.nama)}
                                </div>
                            </td>
                            <td>${escapeHtml(p.guru)}</td>
                            <td>${p.programList.map(programBadge).join(' ')}</td>
                            <td class="cell-nilai">${p.nilaiTerakhir}</td>
                            <td>${statusBadge(p.statusTerakhir)}</td>
                            <td style="min-width:120px;">
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <div class="progress-track" style="width:60px;">
                                        <div class="progress-fill" style="width:${p.persenProgress}%"></div>
                                    </div>
                                    <span style="font-size:12px; font-weight:700; color:var(--navy-600);">${p.persenProgress}%</span>
                                </div>
                            </td>
                            <td>${formatTanggal(p.timestampTerakhir)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        `}
    `;

    const searchInput = document.getElementById('peserta-search');
    if (searchInput) {
        searchInput.addEventListener('input', debounce((e) => {
            pesertaState.searchQuery = e.target.value;
            applyPesertaFilter();
            requestAnimationFrame(() => {
                const el = document.getElementById('peserta-search');
                if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
            });
        }, 250));
    }
}
